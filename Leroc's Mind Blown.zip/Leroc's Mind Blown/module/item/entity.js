export default class tftloopItem extends Item {


}